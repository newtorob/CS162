/*
	Robert Newton
	CS 162
	readMatrix -- finding the determinant of a 2x2/3x3 matrix
*/

#ifndef DETERMINANT_H
#define DETERMINANT_H

int determinant(int *matrix[], int size);

#endif //DETERMINANT_H
