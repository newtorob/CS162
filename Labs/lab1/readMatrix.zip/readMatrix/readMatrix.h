/*
	Robert Newton
	CS 162
	readMatrix -- finding the determinant of a 2x2/3x3 matrix
*/

#ifndef READMATRIX_H
#define READMATRIX_H

void readMatrix(int *[], int readSize);


#endif //READMATRIX_H
