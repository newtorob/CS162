Lab 8

Instructions to run:

make sure make is installed first, run make all from the folder where the files were unzipped.

Run the ./lab command in the terminal to begin  The main menu will come up
asking which option you want to test on the queue:

1. Add an int to the queue
2. Remove in from queue
3. Print the queue
4. Run the test 
5. Exit

Selecting 5 will exit once you are finished.

Run the `make clean` command in the terminal to get the executables out.
