//Robert Newton
//CS 162
//Langston's ant
//10/09/2016

#ifndef UTILITY_H
#define UTILITY_H

#include <iostream>
#include <limits>
#include <cstdlib>

void validInput();
void inputClear();
void gameMenu(int&, int&, int, int);
#endif